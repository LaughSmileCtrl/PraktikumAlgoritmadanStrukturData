package array_023;

public class Array {

    public static void main(String[] args) {
        char[] kar = new char[11];

        kar[0] = 'B';
        kar[1] = 'e';
        kar[2] = 'l';
        kar[3] = 'a';
        kar[4] = 'j';
        kar[5] = 'a';
        kar[6] = 'r';
        kar[7] = 'J';
        kar[8] = 'a';
        kar[9] = 'v';
        kar[10] = 'a';

        for (int i = 0; i < 11; i++) {
            System.out.println(kar[i]);
        }

    }
}